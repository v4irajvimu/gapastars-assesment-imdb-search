export default interface ISearchParams {
  page: number;
  term: string;
}
