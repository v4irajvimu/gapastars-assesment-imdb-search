export default interface ISearchResponseItem {
  Title: string;
  Year: string;
  imdbID: string;
  Type: string;
  Poster: string;
}
