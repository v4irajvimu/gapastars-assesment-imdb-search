export enum MessageTypes {
  Error = "ERROR",
  Info = "INFO",
}
